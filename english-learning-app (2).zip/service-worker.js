// Service worker for offline functionality
// This file enables caching of resources for offline use

// Cache name - update version when content changes
const CACHE_NAME = 'english-learning-app-v1';

// Resources to cache on install
const RESOURCES_TO_CACHE = [
  '/',
  '/index.html',
  '/favicon.ico',
  '/src/main.js',
  '/src/App.vue',
  '/src/assets/main.css',
  '/public/data/lessons.json',
  '/public/data/vocabulary.json',
  '/public/data/exercises.json',
  '/public/data/assessment-questions.json'
];

// Install event - cache initial resources
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Service Worker: Caching files');
        return cache.addAll(RESOURCES_TO_CACHE);
      })
      .then(() => self.skipWaiting())
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log('Service Worker: Clearing old cache', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// Fetch event - serve from cache or network
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        // Return cached response if found
        if (response) {
          return response;
        }

        // Clone the request - request can only be used once
        const fetchRequest = event.request.clone();

        // Try to fetch from network
        return fetch(fetchRequest)
          .then((response) => {
            // Check if valid response
            if (!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }

            // Clone the response - response can only be used once
            const responseToCache = response.clone();

            // Cache the fetched response
            caches.open(CACHE_NAME)
              .then((cache) => {
                cache.put(event.request, responseToCache);
              });

            return response;
          })
          .catch((error) => {
            // Network request failed, try to serve offline fallback
            console.log('Service Worker: Fetch failed; returning offline fallback', error);
            
            // For API requests, return empty data with appropriate structure
            if (event.request.url.includes('/api/')) {
              return new Response(JSON.stringify({ 
                error: 'You are offline',
                offline: true,
                data: null
              }), {
                headers: { 'Content-Type': 'application/json' }
              });
            }
            
            // For HTML requests, show offline page
            if (event.request.headers.get('accept').includes('text/html')) {
              return caches.match('/offline.html');
            }
            
            // For other requests, just return error
            return new Response('Network error happened', {
              status: 408,
              headers: { 'Content-Type': 'text/plain' }
            });
          });
      })
  );
});

// Background sync for pending operations
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-user-progress') {
    event.waitUntil(syncUserProgress());
  }
});

// Function to sync user progress when online
async function syncUserProgress() {
  // This would normally sync with a server
  // For this offline-first app, we're just logging
  console.log('Service Worker: Syncing user progress');
  
  // In a real app, this would retrieve pending operations from IndexedDB
  // and send them to the server
  return Promise.resolve();
}
